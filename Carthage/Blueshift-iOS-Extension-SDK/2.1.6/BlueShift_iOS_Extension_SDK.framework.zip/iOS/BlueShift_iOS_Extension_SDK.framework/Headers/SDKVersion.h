//
//  SDKVersion.h
//  Pods
//
//  Created by shahas kp on 11/10/17.
//

#ifndef SDKVersion_h
#define SDKVersion_h

#define kSDKVersionNumber   @"2.1.6"

#endif /* SDKVersion_h */
