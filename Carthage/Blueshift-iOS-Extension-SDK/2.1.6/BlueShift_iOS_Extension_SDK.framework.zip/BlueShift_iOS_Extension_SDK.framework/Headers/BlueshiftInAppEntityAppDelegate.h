//
//  BlueshiftInAppEntityAppDelegate.h
//  BlueShift-iOS-Extension-SDK
//
//  Created by Noufal Subair on 23/08/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BlueshiftInAppEntityAppDelegate : NSObject

- (void)addInAppNotificationToDataStore:(NSDictionary *)notificationPayload andAppGroupID:(NSString *)appGroupID;

@end

NS_ASSUME_NONNULL_END
