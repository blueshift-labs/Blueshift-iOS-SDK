//
//  SDKVersion.h
//  Pods
//
//  Created by Shahas on 20/12/16.
//
//

#ifndef SDKVersion_h
#define SDKVersion_h

#define kSDKVersionNumber   @"2.1.10"

#endif /* SDKVersion_h */
