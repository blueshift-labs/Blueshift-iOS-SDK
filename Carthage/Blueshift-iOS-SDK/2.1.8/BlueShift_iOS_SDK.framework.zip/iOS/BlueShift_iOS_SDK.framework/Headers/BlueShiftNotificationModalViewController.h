//
//  BlueShiftPromoNotificationViewController.h
//  BlueShift-iOS-SDK-BlueShiftBundle
//
//  Created by Noufal Subair on 16/07/19.
//

#import <UIKit/UIKit.h>
#import "BlueShiftNotificationViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BlueShiftNotificationModalViewController : BlueShiftNotificationViewController

@end

NS_ASSUME_NONNULL_END
