//
//  BlueShiftNotificationSlideBannerViewController.h
//  BlueShift-iOS-Extension-SDK
//
//  Created by Noufal Subair on 23/07/19.
//

#import <UIKit/UIKit.h>
#import "BlueShiftNotificationViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BlueShiftNotificationSlideBannerViewController : BlueShiftNotificationViewController

@end

NS_ASSUME_NONNULL_END
